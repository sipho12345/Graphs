

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class SimulatorOne {
	 
	
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		 String[] nodeH;
		 String[] nodeV;
		 Graph d = new Graph();
		
		try
		{

        Scanner graphFile = new Scanner(System.in);
        ArrayList<String> dataofFile = new ArrayList<String>();
        
        while(graphFile.hasNextLine()){
        	dataofFile.add(graphFile.nextLine());
         }
        if(dataofFile.size()<1)
        	throw new IOException("The input file is empty");
        
        int num_nodes = Integer.parseInt(dataofFile.get(0));
        	
        for(int j = 1; j <= num_nodes; j++){
        	String[] addingData = dataofFile.get(j).split("\\s+");
        	for(int i = 1; i < addingData.length; i +=2){
        		d.addEdge(addingData[0], addingData[i], Integer.parseInt(addingData[i+1]));
        	}
        	
          }
             
             
            nodeH = dataofFile.get(num_nodes+2).split("\\s+");
            nodeV = dataofFile.get(num_nodes+4).split("\\s+");
            
       
            for(String patients : nodeV){
            	patients = patients.trim();
                System.out.println("victim "+patients);
                d.dijkstra(patients);
                ArrayList<ShortestPath> shortestpaths = new ArrayList<ShortestPath>();
            

             for(String checkpoint : nodeH){
            	shortestpaths.add(d.shortestPath(checkpoint));
               }
            ArrayList<ShortestPath> shorter_P = new ArrayList<ShortestPath>();
            Double Min = 99999999.0;
            
            
            for (ShortestPath track : shortestpaths){
                d.dijkstra(track.dest);
                ShortestPath temp = d.shortestPath( patients );
                Double New = track.cost + temp.cost;
                
                String TemporaryPath = track.path;
                if (TemporaryPath != null ){
                    if (New < Min){
                    	
                        shorter_P.clear();
                        shorter_P.add( new ShortestPath(track.dest, New, temp.path + track.path.substring( track.path.indexOf(" ") ) ) );
                        Min = New;
                    } 
                    
                    else if( (New  - Min) < 0.00001){
                        shorter_P.add( new ShortestPath(track.dest, New, temp.path + track.path.substring( track.path.indexOf(" ") ) ) );
                    } 
                 }
              }
            
            for (ShortestPath shortTrack: shorter_P){
                if (shorter_P.size() < 1){
                    System.out.println("cannot be helped");
                }
                
                System.out.println("hospital "+shortTrack.dest);
                System.out.println(shortTrack.path);
             }
           }  
		 }
        
		
		catch( IOException e )
        { System.err.println( e ); }
        
	}
}

